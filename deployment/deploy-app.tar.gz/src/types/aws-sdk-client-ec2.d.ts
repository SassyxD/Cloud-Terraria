declare module '@aws-sdk/client-ec2';
